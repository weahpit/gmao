function getAllLots(ctrl_name, ctrl_type){
    let contentCtrl = ''
    $.ajax({
        url : URL_APP + 'api/getAllLots',
        type : 'POST',
        success: function (response){
            let reponse = JSON.parse(response)
            if (ctrl_type === 1){
                contentCtrl +=`
                <table class="table table-hover">
                    <thead><tr>
                            <th>Lot</th>
                            <th>Proprietaire</th>
                    </tr></thead>
                    <tbody>
                `
                for (var i=0;i < reponse.data.length;i++){
                    contentCtrl +='<tr>'
                    contentCtrl +='<td><a href="#">' + reponse.data[i].lot + '</a></td>'
                    contentCtrl +='<td><a href="#">' + reponse.data[i].proprietaire + '</a></td>'
                    contentCtrl +='<tr>'
                }
                contentCtrl +='</tbody></table>';
            } else {
                contentCtrl += '<option value="0">-- Lots --</option>'
                for (var i=0;i < reponse.data.length;i++) {
                    contentCtrl += '<option value="' + reponse.data[i].id + '">' + reponse.data[i].lot + '</option>'
                }
            }
            ctrl_name.innerHTML = contentCtrl
            if (ctrl_type === 1){ enhanceTable(".table",{ pageSize: 10, filename: 'lots.csv' })}
        },
        error : function (response){
            showToast(response.msg, {title: 'Erreur sur Chargement des  Lots}', type: 'error', duration: 4000 })
        }
    })
}

function getAllLotsByProprietaire(ctrl_name, ctrl_type, id_lot){
    let contentCtrl = ''
    $.ajax({
        url : URL_APP + 'api/getAllLotsByProprietaire/' + id_lot,
        type : 'POST',
        success: function (response){
            let reponse = JSON.parse(response)
            if (ctrl_type === 1){
                contentCtrl +=`
                <table class="table table-hover">
                    <thead><tr>
                            <th>Lot</th>
                            <th>Proprietaire</th>
                    </tr></thead>
                    <tbody>
                `
                for (var i=0;i < reponse.data.length;i++){
                    contentCtrl +='<tr>'
                    contentCtrl +='<td><a href="#">' + reponse.data[i].lot + '</a></td>'
                    contentCtrl +='<td><a href="#">' + reponse.data[i].proprietaire + '</a></td>'
                    contentCtrl +='<tr>'
                }
                contentCtrl +='</tbody></table>';
            } else {
                contentCtrl += '<option value="0">-- Lots --</option>'
                for (var i=0;i < reponse.data.length;i++) {
                    contentCtrl += '<option value="' + reponse.data[i].id + '">' + reponse.data[i].lot + '</option>'
                }
            }
            ctrl_name.innerHTML = contentCtrl
            if (ctrl_type === 1){ enhanceTable(".table",{ pageSize: 10, filename: 'lots.csv' })}
        },
        error : function (response){
            showToast(response.msg, {title: 'Erreur sur Chargement des  Lots}', type: 'error', duration: 4000 })
        }
    })
}
function saveLot(formData, ctrl_name, ctrl_type){
    fetch( URL_APP + "api/saveLot", { method: "POST", body: formData })
        .then(res => res.json())
        .then(data => {
            showToast(data.msg, {
                type : data.code,
                duration: 2000,
                title: 'Lot'
            })
            if (data.code === "success") {
                clearForm("formLot", "lot")
                getAllLots(ctrl_name, ctrl_type)
            }
        })
        .catch(err => showToast("❌ Erreur : " + err, {title: 'Lot', duration: 4000}));
}
function deleteLot(id_lot){
    fetch( URL_APP + "api/deleteLot", { method: "POST", body: id_lot })
        .then(res => res.json())
        .then(data => {
            showToast(data.msg, {
                type : data.code,
                duration: 4000,
                title: 'Lot'
            })
        })
        .catch(err => showToast("❌ Erreur : " + err, {title: 'Lot', duration: 4000}));
}
function getSingleLot(id_lot) {
    return new Promise((resolve, reject) => {
        $.ajax({
            url:  URL_APP + 'api/getSingleLot' + id_lot,
            type: 'POST',
            success: function(response) {
                if (response.code === "success") {
                    resolve(response); // renvoie l'objet au .then()
                } else {
                    showToast(data.msg, {
                        type : data.code,
                        duration: 4000,
                        title: 'Lot'
                    })
                }
            },
            error: function(err) {
                showToast("❌ Erreur : " + err, {title: 'Lot', duration: 4000});
            }
        });
    });
}
