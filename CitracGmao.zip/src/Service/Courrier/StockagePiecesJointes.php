<?php

namespace App\Service\Courrier;

use App\Entity\Courrier\PieceJointeCourrier;
use Symfony\Component\DependencyInjection\Attribute\Autowire;
use Symfony\Component\HttpFoundation\File\UploadedFile;

/**
 * Depot, lecture et suppression des fichiers joints aux courriers.
 *
 * Les fichiers sont ranges dans public/data/courriers/AAAA/MM/ afin que
 * chaque annee reste facile a archiver. Le nom sur disque est genere
 * (jamais le nom fourni par l'utilisateur) : pas de collision, pas de
 * chemin traverse, pas de caractere problematique.
 */
final class StockagePiecesJointes
{
    public function __construct(
        #[Autowire('%kernel.project_dir%')] private string $projectDir,
        #[Autowire('%courrier_pieces_jointes%')] private string $dossierRelatif = 'data/courriers/',
    ) {}

    /** Dossier absolu de stockage. */
    public function dossierAbsolu(?\DateTimeInterface $date = null): string
    {
        $date ??= new \DateTimeImmutable();

        return rtrim($this->projectDir, '/') . '/public/' . $this->dossierRelatif
            . $date->format('Y') . '/' . $date->format('m') . '/';
    }

    /**
     * Enregistre un fichier depose et remplit la fiche de la piece jointe.
     *
     * @throws \RuntimeException si le fichier ne peut pas etre deplace
     */
    public function stocker(UploadedFile $fichier, PieceJointeCourrier $piece): void
    {
        $dossier = $this->dossierAbsolu();
        if (!is_dir($dossier) && !@mkdir($dossier, 0775, true) && !is_dir($dossier)) {
            throw new \RuntimeException('Impossible de creer le dossier de stockage des courriers.');
        }

        $extension = strtolower((string) $fichier->getClientOriginalExtension());
        $extension = preg_replace('/[^a-z0-9]/', '', $extension) ?: 'bin';

        $nom = 'courrier_' . date('Ymd_His') . '_' . bin2hex(random_bytes(5)) . '.' . $extension;

        $fichier->move($dossier, $nom);

        $piece->setFichier(date('Y') . '/' . date('m') . '/' . $nom)
            ->setNomOriginal($this->nettoyerNom($fichier->getClientOriginalName()))
            ->setTypeMime($fichier->getClientMimeType())
            ->setTaille((int) ($fichier->getSize() ?: 0));
    }

    /** Chemin absolu d'un fichier deja stocke. */
    public function chemin(PieceJointeCourrier $piece): ?string
    {
        $relatif = (string) $piece->getFichier();
        if ($relatif === '' || str_contains($relatif, '..')) {
            return null;
        }

        $chemin = rtrim($this->projectDir, '/') . '/public/' . $this->dossierRelatif . $relatif;

        return is_file($chemin) ? $chemin : null;
    }

    /** Supprime le fichier physique (silencieusement s'il est deja absent). */
    public function supprimer(PieceJointeCourrier $piece): void
    {
        $chemin = $this->chemin($piece);
        if ($chemin !== null) {
            @unlink($chemin);
        }
    }

    /** Nom d'origine nettoye, borne a 200 caracteres. */
    private function nettoyerNom(string $nom): string
    {
        $nom = str_replace(['\\', '/'], '-', $nom);
        $nom = preg_replace('/[\x00-\x1F\x7F]/u', '', $nom) ?? $nom;

        return mb_substr(trim($nom) !== '' ? trim($nom) : 'piece-jointe', 0, 200);
    }
}
