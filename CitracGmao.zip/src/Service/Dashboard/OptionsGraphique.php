<?php

namespace App\Service\Dashboard;

/**
 * Traduit un jeu de donnees en options ApexCharts.
 *
 * ApexCharts est deja charge par le gabarit de base du projet : aucune
 * bibliotheque supplementaire n'est necessaire.
 */
final class OptionsGraphique
{
    /** Palette cacao du projet, du plus soutenu au plus clair. */
    public const PALETTE = [
        '#5a371e',
        '#7a4c33',
        '#a5714f',
        '#c9a227',
        '#8a9a5b',
        '#b08968',
        '#3f2a1d',
        '#d9c3a5',
    ];

    public static function pour(array $gadget, array $donnees): array
    {
        $type = $gadget['type'] ?? 'barres';
        $categories = $donnees['categories'] ?? [];
        $series = $donnees['series'] ?? [];

        $base = [
            'chart' => [
                'height' => 265,
                'fontFamily' => 'DM Sans, system-ui, sans-serif',
                'toolbar' => ['show' => false],
                'animations' => ['enabled' => true, 'speed' => 500],
                'parentHeightOffset' => 0,
            ],
            'colors' => self::PALETTE,
            'dataLabels' => ['enabled' => false],
            'stroke' => ['curve' => 'smooth', 'width' => 2.4],
            'grid' => [
                'borderColor' => '#eee3d8',
                'strokeDashArray' => 4,
                'padding' => ['left' => 4, 'right' => 4],
            ],
            'tooltip' => ['theme' => 'light'],
            'legend' => [
                'position' => 'bottom',
                'horizontalAlign' => 'center',
                'fontSize' => '12px',
                'markers' => ['radius' => 4],
                'itemMargin' => ['horizontal' => 6, 'vertical' => 2],
            ],
            'noData' => [
                'text' => 'Aucune donnee sur la periode',
                'align' => 'center',
                'verticalAlign' => 'middle',
                'style' => ['color' => '#8a6a58', 'fontSize' => '13px'],
            ],
        ];

        if ($type === 'donut') {
            return array_merge($base, [
                'chart' => array_merge($base['chart'], ['type' => 'donut']),
                'labels' => $categories,
                'series' => $series[0]['donnees'] ?? [],
                'stroke' => ['width' => 2, 'colors' => ['#ffffff']],
                'plotOptions' => [
                    'pie' => [
                        'donut' => [
                            'size' => '62%',
                            'labels' => [
                                'show' => true,
                                'name' => ['fontSize' => '12px', 'color' => '#8a6a58'],
                                'value' => [
                                    'fontSize' => '20px',
                                    'fontWeight' => 700,
                                    'color' => '#3f2a1d',
                                ],
                                'total' => [
                                    'show' => true,
                                    'label' => 'Total',
                                    'fontSize' => '12px',
                                    'color' => '#8a6a58',
                                ],
                            ],
                        ],
                    ],
                ],
            ]);
        }

        $options = array_merge($base, [
            'series' => $series,
            'xaxis' => [
                'categories' => $categories,
                'labels' => [
                    'style' => ['fontSize' => '11px', 'colors' => '#8a6a58'],
                    'rotate' => count($categories) > 8 ? -35 : 0,
                    'trim' => true,
                ],
                'axisBorder' => ['color' => '#eee3d8'],
                'axisTicks' => ['color' => '#eee3d8'],
            ],
            'yaxis' => [
                'labels' => [
                    'style' => ['fontSize' => '11px', 'colors' => '#8a6a58'],
                    'minWidth' => 24,
                ],
            ],
        ]);

        if ($type === 'barres') {
            $options['chart'] = array_merge($base['chart'], ['type' => 'bar']);
            $options['stroke'] = ['width' => 0];
            $options['plotOptions'] = [
                'bar' => [
                    'horizontal' => false,
                    'columnWidth' => count($series) > 1 ? '58%' : '46%',
                    'borderRadius' => 6,
                    'borderRadiusApplication' => 'end',
                ],
            ];

            return $options;
        }

        if ($type === 'aire') {
            $options['chart'] = array_merge($base['chart'], ['type' => 'area']);
            $options['fill'] = [
                'type' => 'gradient',
                'gradient' => [
                    'shadeIntensity' => 1,
                    'opacityFrom' => 0.35,
                    'opacityTo' => 0.03,
                    'stops' => [0, 90, 100],
                ],
            ];

            return $options;
        }

        $options['chart'] = array_merge($base['chart'], ['type' => 'line']);
        $options['markers'] = ['size' => 4, 'strokeWidth' => 0, 'hover' => ['size' => 6]];

        return $options;
    }
}
